import argparse
import datetime as dt
import json
import math
import re
import sqlite3
from pathlib import Path
from statistics import median


TIME_ONLY_PATTERN = re.compile(r"^(\d{1,2}):(\d{2}):(\d{2})$")


def clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
	return max(low, min(high, value))


def round2(value: float) -> float:
	return round(float(value), 2)


def parse_timestamp(raw_value):
	if raw_value is None:
		return None, None

	value = str(raw_value).strip()
	if not value:
		return None, None

	match = TIME_ONLY_PATTERN.match(value)
	if match:
		hours = int(match.group(1))
		minutes = int(match.group(2))
		seconds = int(match.group(3))
		if hours < 24 and minutes < 60 and seconds < 60:
			return "clock", hours * 3600 + minutes * 60 + seconds
		return None, None

	iso_value = value.replace("Z", "+00:00")
	try:
		parsed = dt.datetime.fromisoformat(iso_value)
		if parsed.tzinfo is None:
			parsed = parsed.replace(tzinfo=dt.timezone.utc)
		return "epoch", parsed.timestamp()
	except ValueError:
		return None, None


def to_timestamp_ms(raw_value):
	"""Millis comparable cu backend.js toTimestamp (inclusiv HH:MM:SS de la ESP)."""
	if raw_value is None:
		return None
	kind, val = parse_timestamp(raw_value)
	if kind == "clock":
		return float(val) * 1000.0
	if kind == "epoch":
		return float(val) * 1000.0
	s = str(raw_value).strip().replace("Z", "+00:00")
	try:
		parsed = dt.datetime.fromisoformat(s)
		if parsed.tzinfo is None:
			parsed = parsed.replace(tzinfo=dt.timezone.utc)
		return parsed.timestamp() * 1000.0
	except (ValueError, OSError):
		return None


def _table_exists(cursor, name: str) -> bool:
	cursor.execute(
		"SELECT 1 FROM sqlite_master WHERE type='table' AND name=? LIMIT 1",
		(name,),
	)
	return cursor.fetchone() is not None


def estimate_pressure_trend_pa_per_hour(sorted_rows):
	"""Aliniat cu backend.js estimatePressureTrendPaPerHour."""
	if not sorted_rows or len(sorted_rows) < 2:
		return None
	last = sorted_rows[-1]
	ref = last["_ts"]
	window_ms = 90 * 60 * 1000
	in_win = [r for r in sorted_rows if r["_ts"] >= ref - window_ms and math.isfinite(r["pressure"])]
	if len(in_win) < 2:
		return None
	first, end = in_win[0], in_win[-1]
	dt_ms = end["_ts"] - first["_ts"]
	min_span_ms = 20 * 60 * 1000
	if dt_ms < min_span_ms:
		return None
	p0, p1 = float(first["pressure"]), float(end["pressure"])
	if not (math.isfinite(p0) and math.isfinite(p1)):
		return None
	hours = dt_ms / 3600000.0
	return (p1 - p0) / hours


def compute_air_ventilation(sorted_rows, dht_row):
	"""Aceleași praguri ca backend.js computeAirVentilation → comfort_score / air_quality."""
	hum = None
	temp = None
	if dht_row is not None:
		try:
			hum = float(dht_row["humidity"])
			temp = float(dht_row["temperature"])
		except (TypeError, ValueError, KeyError):
			hum, temp = None, None

	last_p = None
	if sorted_rows:
		lp = sorted_rows[-1]["pressure"]
		if math.isfinite(lp):
			last_p = float(lp)

	h_pts = 0.0
	h_note = None
	if hum is not None and math.isfinite(hum):
		if hum >= 75:
			h_pts, h_note = 50.0, "Umiditate foarte ridicată"
		elif hum >= 68:
			h_pts, h_note = 36.0, "Umiditate ridicată"
		elif hum >= 62:
			h_pts, h_note = 22.0, "Umiditate peste confort"
		elif hum >= 58:
			h_pts, h_note = 10.0, "Umiditate ușor ridicată"
		elif hum < 30:
			h_pts, h_note = 12.0, "Aer foarte uscat"
		elif hum < 35:
			h_pts = 5.0

	t_pts = 0.0
	t_note = None
	if temp is not None and math.isfinite(temp):
		if temp >= 29:
			t_pts, t_note = 42.0, "Temperatură ridicată"
		elif temp >= 26.5:
			t_pts, t_note = 28.0, "Cald — ventilație utilă"
		elif temp >= 25:
			t_pts, t_note = 14.0, "Peste confort termic"
		elif temp <= 16:
			t_pts, t_note = -18.0, "Frig în cameră"
		elif temp <= 17.5:
			t_pts, t_note = -10.0, "Temperatură scăzută"
		elif temp <= 18.5:
			t_pts = -4.0

	trend = estimate_pressure_trend_pa_per_hour(sorted_rows)
	p_pts = 0.0
	if trend is not None and math.isfinite(trend):
		if trend < -200:
			p_pts = 8.0
		elif trend < -120:
			p_pts = 5.0
		elif trend > 220:
			p_pts = -4.0

	raw = h_pts + t_pts + p_pts
	need = int(round(clamp(raw, 0.0, 100.0)))
	comfort = int(round(clamp(100.0 - need * 0.92, 0.0, 100.0)))
	has_dht = hum is not None and temp is not None and math.isfinite(hum) and math.isfinite(temp)

	if not has_dht:
		label = "unknown"
	elif comfort >= 75:
		label = "good"
	elif comfort >= 55:
		label = "moderate"
	else:
		label = "poor"

	recommendation_ro = ""
	open_window = False
	if not has_dht:
		recommendation_ro = (
			"Date insuficiente: trimite citiri DHT22 (temperatură + umiditate) pentru o recomandare de geam."
		)
		if last_p is not None and math.isfinite(last_p) and trend is not None and math.isfinite(trend):
			recommendation_ro += (
				" Trend presiune BMP este disponibil, dar fără umiditate/temperatură aer recomandarea e incompletă."
			)
	elif temp <= 17 and need < 35:
		recommendation_ro = (
			"Nu deschide geamul pentru răcire — temperatură deja scăzută. Aerisește scurt doar dacă umiditatea e mare."
		)
		open_window = False
	elif need >= 62:
		recommendation_ro = "Da — deschide geamul 10–15 minute pentru aerisire (umiditate sau căldură)."
		open_window = True
	elif need >= 38:
		recommendation_ro = "Recomandat — aerisește câteva minute."
		open_window = True
	elif need >= 22:
		recommendation_ro = "Opțional — poți deschide geamul scurt dacă simți aer închis."
		open_window = False
	else:
		recommendation_ro = "Nu e nevoie să deschizi geamul acum (parametri în interval confortabil)."
		open_window = False

	return {
		"ventilation_need_0_100": need,
		"indoor_confort_0_100": comfort,
		"open_window_recommended": open_window,
		"recommendation_ro": recommendation_ro,
		"humidity_pct": round2(hum) if has_dht else None,
		"temperature_c": round2(temp) if has_dht else None,
		"pressure_last_pa": last_p,
		"pressure_trend_pa_per_hour": round2(trend) if trend is not None and math.isfinite(trend) else None,
		"components": {
			"humidity_points": h_pts,
			"temperature_points": t_pts,
			"pressure_points": p_pts,
		},
		"notes": [n for n in (h_note, t_note) if n],
		"has_dht": has_dht,
		"has_pressure_trend": trend is not None and math.isfinite(trend),
		"label": label,
	}


def compute_sitting_and_fatigue(sorted_rows):
	"""total_sitting_time + fatigue_risk ca în backend.js getMetrics."""
	if not sorted_rows:
		return {
			"total_sitting_minutes": 0,
			"fatigue_risk": 0.0,
		}
	ref = sorted_rows[-1]["_ts"]
	two_h_ms = 2 * 60 * 60 * 1000
	max_gap = 10 * 60 * 1000

	total_ms = 0.0
	for i in range(1, len(sorted_rows)):
		prev, cur = sorted_rows[i - 1], sorted_rows[i]
		delta = cur["_ts"] - prev["_ts"]
		if 0 < delta < max_gap and prev["seat_occupied"]:
			total_ms += delta
	total_minutes = int(round(total_ms / 60000.0))

	recent = [r for r in sorted_rows if r["_ts"] >= ref - two_h_ms]
	recent_minutes = 0.0
	for i in range(1, len(recent)):
		prev, cur = recent[i - 1], recent[i]
		delta = cur["_ts"] - prev["_ts"]
		if 0 < delta < max_gap and prev["seat_occupied"]:
			recent_minutes += delta / 60000.0
	recent_sitting_minutes = min(120, round(recent_minutes))
	sitting_risk = recent_sitting_minutes / 120.0
	fatigue_risk = round(min(1.0, sitting_risk * 0.8 + 0.1), 2)

	return {
		"total_sitting_minutes": total_minutes,
		"fatigue_risk": fatigue_risk,
	}


def format_sitting_duration(total_minutes: int) -> str:
	if total_minutes <= 0:
		return "0m"
	h, m = divmod(total_minutes, 60)
	if h > 0:
		return f"{h}h {m}m"
	return f"{m}m"


def build_sorted_sensor_rows(rows):
	out = []
	for row in rows:
		ts = to_timestamp_ms(row["timestamp"])
		if ts is None:
			continue
		try:
			pf = float(row["pressure"])
			if not math.isfinite(pf):
				pf = float("nan")
		except (TypeError, ValueError):
			pf = float("nan")
		seat = row["seat_occupied"]
		occ = bool(int(seat)) if seat is not None else False
		out.append({"pressure": pf, "seat_occupied": occ, "_ts": ts})
	out.sort(key=lambda r: r["_ts"])
	return out


def fetch_latest_dht_row(cursor):
	if not _table_exists(cursor, "dht22_readings"):
		return None
	cursor.execute(
		"SELECT temperature, humidity, timestamp FROM dht22_readings ORDER BY id DESC LIMIT 1"
	)
	r = cursor.fetchone()
	return dict(r) if r else None


def fetch_latest_posture_row(cursor):
	if not _table_exists(cursor, "posture_samples"):
		return None
	cursor.execute(
		"""
		SELECT timestamp, status, tilt_deg, forward_lean, slouching, close_to_monitor,
		       too_slouched, person_detected, source
		FROM posture_samples
		ORDER BY id DESC
		LIMIT 1
		"""
	)
	r = cursor.fetchone()
	return dict(r) if r else None


def slouch_position_from_row(posture):
	if not posture:
		return None

	def _b(key):
		v = posture.get(key)
		if v is None:
			return False
		try:
			return bool(int(v))
		except (TypeError, ValueError):
			return bool(v)

	td = posture.get("tilt_deg")
	fl = posture.get("forward_lean")
	return {
		"status": posture.get("status"),
		"tilt_deg": round2(td) if td is not None else None,
		"forward_lean": round2(fl) if fl is not None else None,
		"too_slouched": _b("too_slouched"),
		"slouching": _b("slouching"),
		"close_to_monitor": _b("close_to_monitor"),
		"person_detected": _b("person_detected"),
		"source": posture.get("source"),
		"timestamp": posture.get("timestamp"),
	}


def robust_outlier_rate(values):
	if len(values) < 5:
		return 0.0

	center = median(values)
	deviations = [abs(value - center) for value in values]
	mad = median(deviations)

	if mad == 0:
		outliers = sum(1 for value in values if value != center)
		return outliers / len(values)

	threshold = 6.0
	outliers = 0
	for value in values:
		robust_z = 0.6745 * (value - center) / mad
		if abs(robust_z) > threshold:
			outliers += 1
	return outliers / len(values)


def grade_from_score(score):
	if score >= 90:
		return "A"
	if score >= 80:
		return "B"
	if score >= 70:
		return "C"
	if score >= 60:
		return "D"
	return "F"


def build_default_db_path():
	return Path(__file__).resolve().parents[1] / "sensor-readings.db"


def compute_quality_report(db_path: Path):
	conn = sqlite3.connect(str(db_path))
	conn.row_factory = sqlite3.Row
	cursor = conn.cursor()

	cursor.execute(
		"""
		SELECT id, pressure, temperature, seat_occupied, timestamp
		FROM sensor_readings
		ORDER BY id ASC
		"""
	)
	rows = cursor.fetchall()

	dht_row = fetch_latest_dht_row(cursor)
	posture_row = fetch_latest_posture_row(cursor)
	slouch_position = slouch_position_from_row(posture_row)

	if not rows:
		air_detail = compute_air_ventilation([], dht_row)
		conn.close()
		tm = 0
		return {
			"database": str(db_path),
			"records": 0,
			"overall_score": 0.0,
			"grade": "F",
			"message": "No records found in sensor_readings",
			"air_quality": {
				"comfort_index_0_100": air_detail["indoor_confort_0_100"],
				"ventilation_need_0_100": air_detail["ventilation_need_0_100"],
				"label": air_detail["label"],
				"open_window_recommended": air_detail["open_window_recommended"],
				"recommendation_ro": air_detail["recommendation_ro"],
				"humidity_pct": air_detail["humidity_pct"],
				"temperature_c": air_detail["temperature_c"],
				"pressure_last_pa": round2(air_detail["pressure_last_pa"])
				if air_detail["pressure_last_pa"] is not None
				and math.isfinite(air_detail["pressure_last_pa"])
				else None,
				"pressure_trend_pa_per_hour": air_detail["pressure_trend_pa_per_hour"],
				"has_dht": air_detail["has_dht"],
				"has_pressure_trend": air_detail["has_pressure_trend"],
				"notes": air_detail["notes"],
				"components": air_detail["components"],
			},
			"comfort_score": air_detail["indoor_confort_0_100"],
			"total_sitting_time": {
				"minutes": tm,
				"hours": round2(tm / 60.0),
				"formatted": format_sitting_duration(tm),
			},
			"fatigue_risk": 0.0,
			"slouch_position": slouch_position,
		}

	sorted_sensor = build_sorted_sensor_rows(rows)
	air_detail = compute_air_ventilation(sorted_sensor, dht_row)
	sitting_stats = compute_sitting_and_fatigue(sorted_sensor)

	total = len(rows)

	pressure_values = []
	temperature_values = []
	seat_values = []
	parsed_timestamps = []
	timestamp_parse_success = 0

	missing_fields = {
		"pressure": 0,
		"temperature": 0,
		"seat_occupied": 0,
		"timestamp": 0,
	}

	valid_counts = {
		"pressure": 0,
		"temperature": 0,
		"seat_occupied": 0,
		"timestamp": 0,
	}

	for row in rows:
		pressure = row["pressure"]
		temperature = row["temperature"]
		seat = row["seat_occupied"]
		timestamp = row["timestamp"]

		if pressure is None:
			missing_fields["pressure"] += 1
		else:
			pressure_num = float(pressure)
			pressure_values.append(pressure_num)
			if 30000 <= pressure_num <= 120000:
				valid_counts["pressure"] += 1

		if temperature is None:
			missing_fields["temperature"] += 1
		else:
			temperature_num = float(temperature)
			temperature_values.append(temperature_num)
			if -40 <= temperature_num <= 85:
				valid_counts["temperature"] += 1

		if seat is None:
			missing_fields["seat_occupied"] += 1
		else:
			seat_num = int(seat)
			seat_values.append(seat_num)
			if seat_num in (0, 1):
				valid_counts["seat_occupied"] += 1

		ts_kind, ts_value = parse_timestamp(timestamp)
		if ts_kind is None:
			missing_fields["timestamp"] += 1
		else:
			parsed_timestamps.append((ts_kind, ts_value))
			timestamp_parse_success += 1
			valid_counts["timestamp"] += 1

	cursor.execute(
		"""
		SELECT COUNT(*) AS duplicate_rows
		FROM (
		  SELECT pressure, temperature, seat_occupied, timestamp, COUNT(*) AS c
		  FROM sensor_readings
		  GROUP BY pressure, temperature, seat_occupied, timestamp
		  HAVING c > 1
		)
		"""
	)
	duplicate_groups = int(cursor.fetchone()["duplicate_rows"])

	cursor.execute(
		"""
		SELECT COUNT(*) AS distinct_rows
		FROM (
		  SELECT DISTINCT pressure, temperature, seat_occupied, timestamp
		  FROM sensor_readings
		)
		"""
	)
	distinct_rows = int(cursor.fetchone()["distinct_rows"])

	conn.close()

	tm = sitting_stats["total_sitting_minutes"]
	wellness_block = {
		"air_quality": {
			"comfort_index_0_100": air_detail["indoor_confort_0_100"],
			"ventilation_need_0_100": air_detail["ventilation_need_0_100"],
			"label": air_detail["label"],
			"open_window_recommended": air_detail["open_window_recommended"],
			"recommendation_ro": air_detail["recommendation_ro"],
			"humidity_pct": air_detail["humidity_pct"],
			"temperature_c": air_detail["temperature_c"],
			"pressure_last_pa": round2(air_detail["pressure_last_pa"])
			if air_detail["pressure_last_pa"] is not None
			and math.isfinite(air_detail["pressure_last_pa"])
			else None,
			"pressure_trend_pa_per_hour": air_detail["pressure_trend_pa_per_hour"],
			"has_dht": air_detail["has_dht"],
			"has_pressure_trend": air_detail["has_pressure_trend"],
			"notes": air_detail["notes"],
			"components": air_detail["components"],
		},
		"comfort_score": air_detail["indoor_confort_0_100"],
		"total_sitting_time": {
			"minutes": tm,
			"hours": round2(tm / 60.0),
			"formatted": format_sitting_duration(tm),
		},
		"fatigue_risk": sitting_stats["fatigue_risk"],
		"slouch_position": slouch_position,
	}

	completeness_ratio = 1.0 - (
		sum(missing_fields.values()) / (total * 4)
	)
	completeness_score = clamp(completeness_ratio * 100)

	validity_ratio = (
		valid_counts["pressure"]
		+ valid_counts["temperature"]
		+ valid_counts["seat_occupied"]
		+ valid_counts["timestamp"]
	) / (total * 4)
	validity_score = clamp(validity_ratio * 100)

	uniqueness_ratio = distinct_rows / total
	uniqueness_score = clamp(uniqueness_ratio * 100)

	intervals = []
	rollover_count = 0
	for index in range(1, len(parsed_timestamps)):
		prev_kind, prev_value = parsed_timestamps[index - 1]
		cur_kind, cur_value = parsed_timestamps[index]
		if prev_kind != cur_kind:
			continue

		delta = cur_value - prev_value
		if prev_kind == "clock" and delta < 0:
			delta += 24 * 3600
			rollover_count += 1

		if delta >= 0:
			intervals.append(delta)

	if intervals:
		continuity_ratio = sum(1 for gap in intervals if 0 < gap <= 5) / len(intervals)
		continuity_score = clamp(continuity_ratio * 100)
		max_gap_seconds = max(intervals)
		median_gap_seconds = median(intervals)
	else:
		continuity_score = 0.0
		max_gap_seconds = None
		median_gap_seconds = None

	pressure_outlier_rate = robust_outlier_rate(pressure_values)
	temperature_outlier_rate = robust_outlier_rate(temperature_values)
	outlier_rate = (pressure_outlier_rate + temperature_outlier_rate) / 2 if (pressure_values and temperature_values) else 0.0
	outlier_score = clamp((1.0 - outlier_rate) * 100)

	volume_score = clamp((total / 500) * 100)

	epoch_values = [value for kind, value in parsed_timestamps if kind == "epoch"]
	if epoch_values:
		age_seconds = max(0.0, dt.datetime.now(dt.timezone.utc).timestamp() - max(epoch_values))
		freshness_score = clamp((1.0 - min(age_seconds, 3600) / 3600) * 100)
		freshness_note = "computed from absolute timestamps"
	else:
		freshness_score = 50.0
		freshness_note = "defaulted because timestamps are relative time-only strings"

	seat_distribution = {
		"0": seat_values.count(0),
		"1": seat_values.count(1),
	}

	dimensions = {
		"completeness": round2(completeness_score),
		"validity": round2(validity_score),
		"uniqueness": round2(uniqueness_score),
		"continuity": round2(continuity_score),
		"outlier_robustness": round2(outlier_score),
		"volume": round2(volume_score),
		"freshness": round2(freshness_score),
	}

	weights = {
		"completeness": 0.2,
		"validity": 0.2,
		"uniqueness": 0.15,
		"continuity": 0.15,
		"outlier_robustness": 0.1,
		"volume": 0.1,
		"freshness": 0.1,
	}

	overall = sum(dimensions[key] * weights[key] for key in dimensions)

	return {
		"database": str(db_path),
		"records": total,
		"overall_score": round2(overall),
		"grade": grade_from_score(overall),
		"dimension_scores": dimensions,
		**wellness_block,
		"metrics": {
			"missing_fields": missing_fields,
			"valid_counts": valid_counts,
			"distinct_rows": distinct_rows,
			"duplicate_groups": duplicate_groups,
			"timestamp_parse_success": timestamp_parse_success,
			"max_gap_seconds": round2(max_gap_seconds) if max_gap_seconds is not None else None,
			"median_gap_seconds": round2(median_gap_seconds) if median_gap_seconds is not None else None,
			"clock_rollovers": rollover_count,
			"pressure_range": {
				"min": round2(min(pressure_values)) if pressure_values else None,
				"max": round2(max(pressure_values)) if pressure_values else None,
			},
			"temperature_range": {
				"min": round2(min(temperature_values)) if temperature_values else None,
				"max": round2(max(temperature_values)) if temperature_values else None,
			},
			"seat_distribution": seat_distribution,
			"pressure_outlier_rate": round2(pressure_outlier_rate * 100),
			"temperature_outlier_rate": round2(temperature_outlier_rate * 100),
			"freshness_note": freshness_note,
		},
	}


def main():
	parser = argparse.ArgumentParser(description="Compute data quality scores from sensor-readings.db")
	parser.add_argument(
		"--db-path",
		default=str(build_default_db_path()),
		help="Path to sensor-readings.db",
	)
	parser.add_argument(
		"--compact",
		action="store_true",
		help="Print compact JSON output",
	)
	args = parser.parse_args()

	db_path = Path(args.db_path).expanduser().resolve()
	if not db_path.exists():
		raise FileNotFoundError(f"Database not found: {db_path}")

	report = compute_quality_report(db_path)
	if args.compact:
		print(json.dumps(report, separators=(",", ":")))
	else:
		print(json.dumps(report, indent=2))


if __name__ == "__main__":
	main()
